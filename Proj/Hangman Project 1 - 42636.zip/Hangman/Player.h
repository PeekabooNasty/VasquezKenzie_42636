/* 
 * Author: Kenzie Vasquez
 * Created on April 10, 2017, 4:22 PM
 * Purpose: Stores player's name and score for leaderboards
 */

#ifndef PLAYER_H
#define PLAYER_H

struct Player {
    unsigned short SIZE;
    string name;
    int scor;
};

#endif /* PLAYER_H */