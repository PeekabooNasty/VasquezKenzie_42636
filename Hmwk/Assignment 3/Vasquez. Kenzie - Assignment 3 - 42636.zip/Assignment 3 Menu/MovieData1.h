/* 
 * Author: Kenzie Vasquez
 * Created on March 26, 2017, 2:52 PM
 */

#ifndef MOVIEDATA_H
#define MOVIEDATA_H

struct MovieData1 {
    string title;
    string direct;
    short yr;
    short runTime;
} movie1, movie2;

#endif /* MOVIEDATA_H */

