/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * Author: Kenzie Vasquez
 * Created on March 23, 2017, 9:14 AM
 */

#ifndef DIV_H
#define DIV_H

struct Div {
    string name;
    float frstQ;
    float scndQ;
    float thrdQ;
    float frthQ;
    float tot;
    float avg;
};

#endif /* DIV_H */

