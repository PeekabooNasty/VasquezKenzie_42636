/* 
 * Author: Kenzie Vasquez
 * Created on March 23, 2017, 10:15 AM
 */

#ifndef PLAYER_H
#define PLAYER_H

struct Player {
    string name;
    unsigned short num;
    unsigned int score;
};

#endif /* PLAYER_H */

