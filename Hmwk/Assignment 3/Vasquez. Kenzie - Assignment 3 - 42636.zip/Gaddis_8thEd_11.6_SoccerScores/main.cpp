/* 
 * File:   Soccer scores
 * Author: Kenzie Vasquez
 * Created on March 23, 2017, 10:10 AM
 * Purpose:
    Write a program that stores the following data about a soccer player in a structure:
        Player’s Name
        Player’s Number
        Points Scored by Player

    The program should keep an array of 12 of these structures. Each element is for a different
    player on a team. When the program runs it should ask the user to enter the data
    for each player. It should then show a table that lists each player’s number, name, and
    points scored. The program should also calculate and display the total points earned by
    the team. The number and name of the player who has earned the most points should
    also be displayed.

    Input Validation: Do not accept negative values for players’ numbers or points scored.
 */

#include <iostream>
using namespace std;

#include "Player.h"

Player *data(const int);

int main(int argc, char** argv){
    Player *plyr = data(12);
    
    delete [] plyr;
    
    return 0;
}

Player *data(const int SIZE){
    Player *ptr = new Player[SIZE];
    int sum = 0,
        high = 0,
        index = 0;
    
    for(int i = 0; i < SIZE; i++){
        cout << "PLAYER " << i + 1 << endl;
        cout << "Name: ";
        getline(cin, ptr[i].name);
        
        do {
           cout << "Number: ";
           cin >> ptr[i].num; cin.ignore();
        } while(ptr[i].num < 0 || ptr[i].num > 4294967295);
        
        do {
            cout << "Score: ";
            cin >> ptr[i].score; cin.ignore();
        } while(ptr[i].score < 0 || ptr[i].num > 4294967295);
        
        sum += ptr[i].score;
        
        if(ptr[i].score > high){ //If a new higher score is found
            high = ptr[i].score;
            index = i;
        }
        
        cout << endl;
    }
    
    cout << "Total team score: " << sum << endl << endl;
    cout << "HI-SCORE\n" << "#" << ptr[index].num << " " << ptr[index].name << endl;
    
    return ptr;
}